# Minimal Quant Trading Agent
## Lernprojekt — pure Anthropic API, kein Framework

---

## Setup

```bash
# 1. Dependencies installieren
pip install anthropic yfinance python-dotenv

# 2. API Key setzen
export ANTHROPIC_API_KEY=your-key-here

# 3. Agent starten
python agent.py
```

---

## Was du hier lernst

```
User Query
    │
    ▼
Claude (Reasoning)
    │
    ├── Tool Call: get_price_data()
    │       └── yfinance → historische Kurse
    │
    ├── Tool Call: calculate_metrics()
    │       └── SMA, RSI, Volatilität
    │
    ├── Tool Call: get_news_sentiment()
    │       └── Headlines → Claude Haiku → Sentiment JSON
    │
    ▼
Claude (Synthesis)
    │
    ▼
BUY / HOLD / SELL + Begründung
```

**Kernkonzepte:**
- **Tool Use / Function Calling** — Claude entscheidet selbst welche Tools es braucht
- **Agenten-Schleife** — Reason → Act → Observe → Repeat
- **Message History** — wie Kontext über mehrere Turns weitergegeben wird
- **Nested LLM Calls** — Haiku für schnelle Subtasks, Sonnet für Reasoning

---

## Projektstruktur

```
quant_agent/
├── agent.py          # Alles in einer Datei — absichtlich, zum Lernen
└── README.md
```

---

## Nächste Schritte zum Erweitern

### Neues Tool hinzufügen (Schritt-für-Schritt)

**1. Tool-Definition in `TOOLS` Liste:**
```python
{
    "name": "get_fundamentals",
    "description": "Fetches P/E ratio, market cap, revenue growth",
    "input_schema": {
        "type": "object",
        "properties": {
            "ticker": {"type": "string"}
        },
        "required": ["ticker"]
    }
}
```

**2. Implementierung:**
```python
def get_fundamentals(ticker: str) -> dict:
    stock = yf.Ticker(ticker)
    info = stock.info
    return {
        "pe_ratio": info.get("trailingPE"),
        "market_cap": info.get("marketCap"),
        "revenue_growth": info.get("revenueGrowth"),
    }
```

**3. Im Dispatcher registrieren:**
```python
elif tool_name == "get_fundamentals":
    result = get_fundamentals(**tool_input)
```

Fertig. Claude weiß automatisch wann es das neue Tool nutzen soll.

---

## Multi-Stock Vergleich

```python
result = run_agent(
    "Compare AAPL, MSFT and GOOGL. Which has the best risk/reward right now?"
)
```

Der Agent wird automatisch alle drei analysieren und vergleichen.

---

## Kosten-Übersicht (ungefähr)

| Analyse | Tokens | Kosten |
|---------|--------|--------|
| Eine Aktie | ~3.000 | ~$0.01 |
| 5 Aktien vergleichen | ~10.000 | ~$0.03 |
| Portfolio (20 Aktien) | ~40.000 | ~$0.12 |

Claude Haiku für Sentiment (günstig), Sonnet für Reasoning (besser).

---

## Weiterführende Ressourcen

- **Anthropic Docs:** docs.anthropic.com/en/docs/build-with-claude/tool-use
- **Building Effective Agents:** anthropic.com/research/building-effective-agents
- **LangGraph (nächster Schritt):** academy.langchain.com
- **ai-hedge-fund (aufbauend):** github.com/virattt/ai-hedge-fund
